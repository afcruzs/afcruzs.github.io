#include <bits/stdc++.h>

using namespace std;

int main(){
    freopen("crd502","r",stdin);
    int ct = 0, aux;
    while( cin >> aux ) ct++;
    cout << "Total tokens: " << ct;
}
